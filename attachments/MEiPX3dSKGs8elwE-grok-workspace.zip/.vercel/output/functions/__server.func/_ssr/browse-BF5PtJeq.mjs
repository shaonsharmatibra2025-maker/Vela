import { i as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, Y as require_react, b as Link, x as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { C as schedule, D as topRated, E as statusLabel, O as useLibrary, S as runLabel, _ as rail, d as genreCounts, f as getMedia, g as newest, i as discoverSearch, l as filterMedia, m as hiddenGems, s as episodeTotal, u as formatLabel, v as randomMedia } from "./catalog-DA4MgMzA.mjs";
import { l as Search, t as X } from "../_libs/lucide-react.mjs";
import { a as Ago, o as When } from "./router-Czyallv3.mjs";
import { i as useKind, n as Shell, r as cn } from "./chrome-BIIY8uqH.mjs";
import { n as Rail, t as Poster } from "./poster-DLYXRVC1.mjs";
import { n as LOUNGE, r as RecentNotes } from "./comments-DMRFf2Rh.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/browse-BF5PtJeq.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Browse() {
	const kind = useKind();
	const navigate = useNavigate();
	const slides = (kind === "ANIME" ? rail("trending") : rail("manga")).filter((m) => m.banner || m.cover).slice(0, 5);
	const [index, setIndex] = (0, import_react.useState)(0);
	const [q, setQ] = (0, import_react.useState)("");
	const featuredId = useLibrary((s) => s.featuredId);
	const pinned = featuredId ? getMedia(featuredId) : void 0;
	const slide = pinned && pinned.kind === kind ? pinned : slides[index % Math.max(slides.length, 1)];
	(0, import_react.useEffect)(() => {
		setIndex(0);
	}, [kind]);
	(0, import_react.useEffect)(() => {
		if (slides.length < 2) return;
		const t = window.setInterval(() => setIndex((n) => (n + 1) % slides.length), 7e3);
		return () => window.clearInterval(t);
	}, [slides.length, kind]);
	const hits = q.trim().length > 1 ? filterMedia({
		kind,
		q,
		sort: "popular"
	}).slice(0, 6) : [];
	const progress = useLibrary((s) => s.progress);
	const watchlist = useLibrary((s) => s.watchlist);
	const dismissed = useLibrary((s) => s.dismissed);
	const dismiss = useLibrary((s) => s.dismiss);
	const continueItems = Object.entries(progress).map(([id, p]) => ({
		media: getMedia(Number(id)),
		episode: p.episode,
		at: p.at
	})).filter((row) => !!row.media && row.media.kind === kind).sort((a, b) => b.at - a.at);
	const saved = watchlist.map((id) => getMedia(id)).filter((m) => !!m && m.kind === kind);
	const airing = schedule(kind).slice(0, 6);
	const top = topRated(kind, 8);
	const genres = genreCounts(kind);
	const commentIds = (kind === "ANIME" ? rail("trending") : rail("manga")).slice(0, 8).map((m) => m.id);
	const rows = (0, import_react.useMemo)(() => {
		if (kind === "MANGA") return [
			{
				title: "Popular manga",
				items: rail("manga")
			},
			{
				title: "Top rated",
				items: rail("mangaScore")
			},
			{
				title: "Quieter scores",
				items: hiddenGems("MANGA")
			},
			{
				title: "Newer on the shelf",
				items: newest("MANGA")
			}
		];
		return [
			{
				title: "Trending",
				items: rail("trending")
			},
			{
				title: "This season",
				items: rail("season")
			},
			{
				title: "Next season",
				items: rail("next")
			},
			{
				title: "Top this year",
				items: rail("year")
			},
			{
				title: "Airing now",
				items: rail("airing")
			},
			{
				title: "Quieter scores",
				items: hiddenGems("ANIME")
			},
			{
				title: "Newer on the shelf",
				items: newest("ANIME")
			}
		];
	}, [kind]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, {
		showSearch: false,
		children: [slide && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "relative min-h-[28rem] overflow-hidden",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: slide.banner || slide.cover,
					alt: "",
					className: "absolute inset-0 h-full w-full object-cover"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-t from-bg via-bg/75 to-bg/30" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative mx-auto flex min-h-[28rem] max-w-3xl flex-col items-center justify-end px-4 pt-16 pb-8 text-center",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-micro tracking-widest text-muted uppercase",
							children: [
								String(index + 1).padStart(2, "0"),
								" / ",
								String(slides.length).padStart(2, "0")
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: slide.cover,
								alt: "",
								className: "h-44 w-32 rounded-2xl border border-line object-cover shadow-2xl"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "pointer-events-none absolute -top-6 -right-10 font-display text-7xl font-extrabold text-fg/10 sm:-right-16",
								children: String(slide.episodes ?? index + 1).padStart(2, "0").slice(-2)
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "mt-4 font-display text-4xl font-extrabold sm:text-6xl",
							children: slide.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-2 text-sm text-muted",
							children: [
								slide.year ?? "—",
								" · ",
								formatLabel(slide.format),
								" · ",
								runLabel(slide),
								" · ",
								statusLabel(slide.status)
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-3 flex flex-wrap justify-center gap-2",
							children: slide.genres.slice(0, 3).map((g) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/discover",
								search: discoverSearch({ genre: g }),
								className: "rounded-full bg-surface/80 px-3 py-1 text-micro text-fg",
								children: g
							}, g))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-5 flex flex-wrap justify-center gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/watch/$id",
								params: { id: String(slide.id) },
								search: { ep: 1 },
								className: "inline-flex h-11 items-center rounded-full bg-accent px-4 text-sm font-semibold text-accent-ink",
								children: kind === "MANGA" ? "Open" : "Watch"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/discover",
								search: discoverSearch(),
								className: "inline-flex h-11 items-center justify-center gap-2 rounded-full border border-line bg-surface px-4 text-sm font-medium text-fg transition-colors duration-200 hover:bg-raised",
								children: "Browse"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
							className: "relative mt-6 w-full max-w-xl",
							onSubmit: (e) => {
								e.preventDefault();
								const query = q.trim();
								if (!query) return;
								navigate({
									to: "/discover",
									search: discoverSearch({ q: query })
								});
							},
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "pointer-events-none absolute top-1/2 left-4 size-4 -translate-y-1/2 text-faint" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									value: q,
									onChange: (e) => setQ(e.target.value),
									placeholder: kind === "MANGA" ? "Search manga" : "Search anime",
									className: "h-12 w-full rounded-full border border-line bg-bg/80 pr-4 pl-11 text-sm backdrop-blur",
									"aria-label": "Search the catalog"
								}),
								hits.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
									className: "absolute z-20 mt-2 w-full overflow-hidden rounded-2xl border border-line bg-raised text-left shadow-xl",
									children: hits.map((hit) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
										to: "/title/$id",
										params: { id: String(hit.id) },
										className: "flex items-center gap-3 px-3 py-2 hover:bg-surface",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
											src: hit.cover,
											alt: "",
											className: "h-12 w-8 rounded object-cover"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "min-w-0",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "block truncate text-sm font-medium",
												children: hit.title
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "text-micro text-muted",
												children: [
													hit.year,
													" · ",
													formatLabel(hit.format)
												]
											})]
										})]
									}) }, hit.id))
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3 flex flex-wrap justify-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/discover",
								search: discoverSearch(),
								className: "inline-flex h-11 items-center rounded-full border border-line bg-bg/70 px-4 text-sm",
								children: "Filters"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "inline-flex h-11 items-center rounded-full border border-line bg-bg/70 px-4 text-sm",
								onClick: () => {
									const next = randomMedia(kind);
									if (next) navigate({
										to: "/title/$id",
										params: { id: String(next.id) }
									});
								},
								children: "Surprise"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-4 flex gap-2",
							children: slides.map((item, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								"aria-label": `Show ${item.title}`,
								onClick: () => setIndex(i),
								className: cn("h-2 rounded-full", i === index && !pinned ? "w-6 bg-accent" : "w-2 bg-fg/40", pinned && "hidden")
							}, item.id))
						})
					]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
			className: "mx-auto max-w-screen-2xl px-4 pb-8",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "mt-8 rounded-2xl border border-line bg-surface p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-sm font-semibold",
						children: "Continue"
					}), continueItems.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {
						title: "No watch history",
						body: "Start a trailer and the episode you opened will sit here.",
						action: "Browse the shelf"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "scroller mt-3 flex w-full min-w-0 gap-3 overflow-x-auto",
						children: continueItems.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/watch/$id",
							params: { id: String(row.media.id) },
							search: { ep: row.episode },
							className: "w-64 shrink-0 overflow-hidden rounded-xl border border-line",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: row.media.banner || row.media.cover,
									alt: "",
									className: "h-28 w-full object-cover"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "h-1 bg-line",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "h-full bg-gold",
										style: { width: `${Math.min(100, Math.round(row.episode / episodeTotal(row.media) * 100))}%` }
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "p-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "truncate text-sm font-semibold",
										children: row.media.title
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-micro text-muted",
										children: [
											"Episode ",
											row.episode,
											" · ",
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ago, { at: row.at })
										]
									})]
								})
							]
						}, row.media.id))
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					id: "list",
					className: "mt-4 rounded-2xl border border-line bg-surface p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-sm font-semibold",
						children: "Your list"
					}), saved.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {
						title: "Your list is empty",
						body: "Follow a title from its page. It stays on this device.",
						action: "Find something"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3 grid grid-cols-3 gap-3 sm:grid-cols-6 lg:grid-cols-8",
						children: saved.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Poster, { media: item }, item.id))
					})]
				}),
				!dismissed.includes("device") && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 flex items-start justify-between gap-3 rounded-2xl border border-line bg-raised px-4 py-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-muted",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-semibold text-fg",
							children: "Kept on this device. "
						}), "Follows, notes, and the lounge transcript are not uploaded."]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "grid size-11 shrink-0 place-items-center text-muted",
						"aria-label": "Dismiss",
						onClick: () => dismiss("device"),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-8 grid grid-cols-1 gap-4 lg:grid-cols-[minmax(0,1.2fr)_minmax(0,0.8fr)]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "min-w-0 rounded-2xl border border-line bg-surface p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-sm font-semibold",
							children: "Recent notes"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RecentNotes, { ids: commentIds })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
						className: "min-w-0 rounded-2xl border border-line bg-surface p-4",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-sm font-semibold",
								children: "Airing next"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
								className: "mt-2 divide-y divide-line",
								children: [airing.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
									className: "py-3 text-sm text-muted",
									children: "Nothing dated on this shelf right now."
								}), airing.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
									to: "/title/$id",
									params: { id: String(item.id) },
									className: "flex items-center gap-3 py-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
											src: item.cover,
											alt: "",
											className: "h-12 w-8 rounded object-cover"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "min-w-0 flex-1",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "block truncate text-sm",
												children: item.title
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "text-micro text-muted",
												children: ["Ep ", item.nextAiring?.episode]
											})]
										}),
										item.nextAiring && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-micro text-faint",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(When, { at: item.nextAiring.at })
										})
									]
								}) }, item.id))]
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-sm font-semibold",
								children: "Top of the shelf"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
								className: "mt-2 space-y-2",
								children: top.map((item, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
									to: "/title/$id",
									params: { id: String(item.id) },
									className: "flex items-center gap-3",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "w-5 text-micro text-faint tabular-nums",
											children: i + 1
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
											src: item.cover,
											alt: "",
											className: "h-10 w-7 rounded object-cover"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "min-w-0 flex-1 truncate text-sm",
											children: item.title
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "text-micro text-accent tabular-nums",
											children: [item.score, "%"]
										})
									]
								}) }, item.id))
							})] })]
						})
					})]
				}),
				rows.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Rail, {
					title: row.title,
					items: row.items,
					action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/discover",
						search: discoverSearch({ sort: row.title.includes("rated") || row.title.includes("year") ? "score" : "popular" }),
						className: "text-sm text-muted hover:text-fg",
						children: "View all"
					})
				}, row.title)),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "mt-10",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-lg font-semibold",
						children: "Genres"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3 grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5",
						children: [
							"Action",
							"Fantasy",
							"Drama",
							"Romance",
							"Horror"
						].map((name) => {
							const sample = filterMedia({
								kind,
								genre: name,
								sort: "popular"
							})[0];
							const count = genres.find(([g]) => g === name)?.[1];
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/discover",
								search: discoverSearch({ genre: name }),
								className: "relative h-28 overflow-hidden rounded-2xl border border-line",
								children: [
									sample && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src: sample.banner || sample.cover,
										alt: "",
										className: "absolute inset-0 h-full w-full object-cover"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute inset-0 bg-bg/60" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "relative flex h-full flex-col justify-end p-3",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "font-semibold",
											children: name
										}), count != null && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "text-micro text-muted",
											children: [count, " titles"]
										})]
									})
								]
							}, name);
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lounge, {})
			]
		})]
	});
}
function Empty({ title, body, action }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "py-6 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-medium",
				children: title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted",
				children: body
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/discover",
				search: discoverSearch(),
				className: "mt-3 inline-flex text-sm text-accent",
				children: action
			})
		]
	});
}
function Lounge() {
	const chat = useLibrary((s) => s.chat);
	const addChat = useLibrary((s) => s.addChat);
	const nick = useLibrary((s) => s.nick);
	const [text, setText] = (0, import_react.useState)("");
	const [booted, setBooted] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		setBooted(true);
		if (useLibrary.getState().chat.length > 0) return;
		LOUNGE.forEach((line, i) => {
			window.setTimeout(() => {
				if (useLibrary.getState().chat.some((c) => c.text === line.text)) return;
				useLibrary.getState().addChat({
					name: line.name,
					text: line.text
				});
			}, 400 * (i + 1));
		});
	}, []);
	const lines = booted ? chat : [];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mt-10 rounded-2xl border border-line bg-surface",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between border-b border-line px-4 py-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-sm font-semibold",
					children: "Lounge"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-micro text-muted",
					children: "On this device · a few regulars drop lines"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
				className: "max-h-80 space-y-3 overflow-y-auto px-4 py-3",
				children: [lines.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
					className: "text-sm text-muted",
					children: "Opening the room…"
				}), lines.map((line) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: line.self ? "font-semibold text-accent" : "font-semibold",
						children: line.name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-muted",
						children: [" · ", line.text]
					})]
				}, line.id))]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "flex gap-2 border-t border-line p-3",
				onSubmit: (e) => {
					e.preventDefault();
					const body = text.trim();
					if (!body) return;
					addChat({
						name: nick || "Guest",
						text: body,
						self: true
					});
					setText("");
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					value: text,
					onChange: (e) => setText(e.target.value),
					placeholder: "Say something to the room",
					className: "h-11 min-w-0 flex-1 rounded-full border border-line bg-bg px-4 text-sm placeholder:text-faint",
					"aria-label": "Lounge message",
					autoComplete: "off",
					suppressHydrationWarning: true
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "submit",
					className: "h-11 rounded-full bg-accent px-4 text-sm font-semibold text-accent-ink",
					children: "Send"
				})]
			})
		]
	});
}
//#endregion
export { Browse as component };
