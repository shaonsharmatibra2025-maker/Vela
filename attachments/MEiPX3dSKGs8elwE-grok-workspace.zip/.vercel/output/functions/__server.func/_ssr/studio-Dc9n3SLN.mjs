import { i as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, Y as require_react, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { E as statusLabel, O as useLibrary, f as getMedia, l as filterMedia, u as formatLabel } from "./catalog-DA4MgMzA.mjs";
import { i as useKind, n as Shell, r as cn, t as Score } from "./chrome-BIIY8uqH.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/studio-Dc9n3SLN.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var THEMES = [
	{
		id: "night",
		name: "Night",
		line: "Near-black canvas, cream button, gold score."
	},
	{
		id: "ember",
		name: "Ember",
		line: "Warmer blacks and a stronger gold."
	},
	{
		id: "dawn",
		name: "Dawn",
		line: "Paper background, ink text, dark button."
	}
];
function Studio() {
	const kind = useKind();
	const theme = useLibrary((s) => s.theme);
	const setTheme = useLibrary((s) => s.setTheme);
	const reduceMotion = useLibrary((s) => s.reduceMotion);
	const setReduceMotion = useLibrary((s) => s.setReduceMotion);
	const featuredId = useLibrary((s) => s.featuredId);
	const setFeatured = useLibrary((s) => s.setFeatured);
	const notes = useLibrary((s) => s.notes);
	const hiddenNotes = useLibrary((s) => s.hiddenNotes);
	const hideNote = useLibrary((s) => s.hideNote);
	const [q, setQ] = (0, import_react.useState)("");
	const featured = featuredId ? getMedia(featuredId) : void 0;
	const rows = (0, import_react.useMemo)(() => filterMedia({
		kind,
		q,
		sort: "popular"
	}).slice(0, 24), [kind, q]);
	const visibleNotes = notes.filter((n) => !hiddenNotes.includes(n.id)).slice(0, 12);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto max-w-5xl px-4 py-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-micro tracking-widest text-faint uppercase",
				children: "Studio"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-1 font-display text-3xl font-bold",
				children: "Arrange the shelf"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 max-w-xl text-sm text-muted",
				children: "Pin the home hero, switch the room, and hide a note. Playback is the official trailer on YouTube. Vela does not host episode files."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-8",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-sm font-semibold",
						children: "Appearance"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3 grid gap-3 sm:grid-cols-3",
						children: THEMES.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => setTheme(item.id),
							className: cn("rounded-2xl border p-4 text-left", theme === item.id ? "border-accent bg-surface" : "border-line bg-surface"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-semibold",
								children: item.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm text-muted",
								children: item.line
							})]
						}, item.id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "mt-3 flex items-center gap-3 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "checkbox",
							checked: reduceMotion,
							onChange: (e) => setReduceMotion(e.target.checked),
							className: "size-4 accent-gold"
						}), "Reduced motion"]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-10",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-sm font-semibold",
						children: "Featured"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted",
						children: "This title holds the home hero until you clear it. Otherwise the shelf rotates."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3 flex items-center gap-3 rounded-2xl border border-line bg-surface p-3",
						children: featured ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: featured.cover,
								alt: "",
								className: "h-20 w-14 rounded-lg object-cover"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0 flex-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "truncate font-semibold",
									children: featured.title
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-micro text-muted",
									children: [
										featured.year ?? "—",
										" · ",
										formatLabel(featured.format)
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "h-11 rounded-full border border-line px-4 text-sm",
								onClick: () => setFeatured(null),
								children: "Clear"
							})
						] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: "No pin. Home is using the rotating row."
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "mt-3 block text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-muted",
							children: "Find a title to pin"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: q,
							onChange: (e) => setQ(e.target.value),
							placeholder: kind === "MANGA" ? "Search manga" : "Search anime",
							className: "mt-1 h-11 w-full rounded-full border border-line bg-surface px-4 text-sm"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-3 divide-y divide-line overflow-hidden rounded-2xl border border-line",
						children: rows.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-center gap-3 bg-surface px-3 py-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: item.cover,
									alt: "",
									className: "h-12 w-8 rounded object-cover"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0 flex-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "truncate text-sm font-medium",
										children: item.title
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-micro text-muted",
										children: [
											statusLabel(item.status),
											" · ",
											item.year ?? "—"
										]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Score, { value: item.score }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "h-11 shrink-0 rounded-full bg-accent px-3 text-sm font-semibold text-accent-ink",
									onClick: () => setFeatured(item.id),
									children: "Pin"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/title/$id",
									params: { id: String(item.id) },
									className: "hidden h-11 items-center text-sm text-muted sm:inline-flex",
									children: "Open"
								})
							]
						}, item.id))
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-10",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-sm font-semibold",
					children: "Notes on this device"
				}), visibleNotes.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted",
					children: "No notes yet. They show up after someone writes under an episode."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-3 space-y-2",
					children: visibleNotes.map((note) => {
						const show = getMedia(note.mediaId);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-start justify-between gap-3 rounded-2xl border border-line bg-surface p-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-micro text-muted",
									children: [
										show?.title ?? "Title",
										" · ep ",
										note.episode
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-sm",
									children: note.text
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "h-11 shrink-0 text-sm text-danger",
								onClick: () => hideNote(note.id),
								children: "Hide"
							})]
						}, note.id);
					})
				})]
			})
		]
	}) });
}
//#endregion
export { Studio as component };
