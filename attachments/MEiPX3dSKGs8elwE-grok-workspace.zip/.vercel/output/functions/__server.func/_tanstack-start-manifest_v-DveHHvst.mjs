//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DveHHvst.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/browse",
			"/discover",
			"/schedule",
			"/studio",
			"/title/$id",
			"/watch/$id"
		],
		preloads: [
			"/assets/index-C6PCcKoA.js",
			"/assets/catalog-DYO7SFSU.js",
			"/assets/preload-helper-D9ke_RvH.js",
			"/assets/useNavigate-CZjZdpzU.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-C6PCcKoA.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-CdN2S9Te.js"]
	},
	"/browse": {
		filePath: "/workspace/src/routes/browse.tsx",
		children: void 0,
		preloads: [
			"/assets/browse-BsamEwgc.js",
			"/assets/chrome-CyE823AC.js",
			"/assets/poster-q9LdQaTi.js",
			"/assets/comments-BSmD0cjm.js"
		]
	},
	"/discover": {
		filePath: "/workspace/src/routes/discover.tsx",
		children: void 0,
		preloads: [
			"/assets/discover-MBK05so8.js",
			"/assets/chrome-CyE823AC.js",
			"/assets/poster-q9LdQaTi.js"
		]
	},
	"/schedule": {
		filePath: "/workspace/src/routes/schedule.tsx",
		children: void 0,
		preloads: ["/assets/schedule-2bTHTsvf.js", "/assets/chrome-CyE823AC.js"]
	},
	"/studio": {
		filePath: "/workspace/src/routes/studio.tsx",
		children: void 0,
		preloads: ["/assets/studio-CnNtSzGV.js", "/assets/chrome-CyE823AC.js"]
	},
	"/title/$id": {
		filePath: "/workspace/src/routes/title/$id.tsx",
		children: void 0,
		preloads: [
			"/assets/_id-B3McTAL7.js",
			"/assets/chrome-CyE823AC.js",
			"/assets/play-Cg-y4vRs.js",
			"/assets/poster-q9LdQaTi.js"
		]
	},
	"/watch/$id": {
		filePath: "/workspace/src/routes/watch/$id.tsx",
		children: void 0,
		preloads: [
			"/assets/_id-hVFLNK5G.js",
			"/assets/chrome-CyE823AC.js",
			"/assets/play-Cg-y4vRs.js",
			"/assets/poster-q9LdQaTi.js",
			"/assets/comments-BSmD0cjm.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
