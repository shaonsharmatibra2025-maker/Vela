import { i as __toESM } from "./_runtime.mjs";
import { C as require_jsx_runtime, Y as require_react, b as Link, x as useNavigate } from "./_libs/@tanstack/react-router+[...].mjs";
import { E as statusLabel, O as useLibrary, S as runLabel, T as solidBtn, f as getMedia, h as inCatalog, i as discoverSearch, o as episodeTitle, p as ghostBtn, s as episodeTotal, u as formatLabel, v as randomMedia, w as seasonText, x as recsFor } from "./_ssr/catalog-DA4MgMzA.mjs";
import { c as Share2, s as Shuffle, u as Play, x as Heart } from "./_libs/lucide-react.mjs";
import { r as Route$1 } from "./_ssr/router-Czyallv3.mjs";
import { n as Shell, r as cn } from "./_ssr/chrome-BIIY8uqH.mjs";
import { t as Poster } from "./_ssr/poster-DLYXRVC1.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_id-jC8__ZML.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var TABS = [
	"Overview",
	"Episodes",
	"Trailer",
	"More like this"
];
function TitlePage() {
	const { id } = Route$1.useParams();
	const media = getMedia(Number(id));
	const navigate = useNavigate();
	const saved = useLibrary((s) => media ? s.watchlist.includes(media.id) : false);
	const toggle = useLibrary((s) => s.toggleWatch);
	const progress = useLibrary((s) => media ? s.progress[String(media.id)] : void 0);
	const [tab, setTab] = (0, import_react.useState)("Overview");
	const [copied, setCopied] = (0, import_react.useState)(false);
	if (!media) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto max-w-lg px-4 py-24 text-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-display text-3xl font-bold",
			children: "That title is not on the shelf"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/browse",
			className: "mt-4 inline-flex text-sm text-accent",
			children: "Back to browse"
		})]
	}) });
	const total = episodeTotal(media);
	const resume = progress?.episode ?? 1;
	const paras = media.synopsis.split(/\n+/).filter(Boolean);
	const more = recsFor(media);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "relative",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "absolute inset-0 overflow-hidden",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: media.banner || media.cover,
				alt: "",
				className: "h-full w-full scale-105 object-cover opacity-40 blur-md"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-b from-bg/30 via-bg/70 to-bg" })]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative mx-auto flex max-w-3xl flex-col items-center px-4 pt-12 pb-8 text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: media.cover,
						alt: "",
						className: "w-40 rounded-2xl border border-line object-cover shadow-2xl sm:w-48"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						"aria-label": saved ? "Remove from list" : "Follow",
						onClick: () => toggle(media.id),
						className: "absolute -right-2 -bottom-2 grid size-11 place-items-center rounded-full border border-line bg-bg",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, { className: cn("size-5", saved ? "fill-accent text-accent" : "text-fg") })
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 flex flex-wrap items-center justify-center gap-2 text-micro text-muted",
					children: [
						media.score > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "rounded-full bg-surface px-2 py-1 text-accent tabular-nums",
							children: [
								"★ ",
								media.score,
								"%"
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "rounded-full bg-surface px-2 py-1",
							children: media.year ?? "—"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "rounded-full bg-surface px-2 py-1",
							children: formatLabel(media.format)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "rounded-full bg-surface px-2 py-1",
							children: runLabel(media)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "rounded-full bg-surface px-2 py-1 tracking-wide uppercase",
							children: statusLabel(media.status)
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-4 font-display text-4xl font-extrabold sm:text-5xl",
					children: media.title
				}),
				media.native && media.native !== media.title && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted",
					children: media.native
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-3 flex flex-wrap justify-center gap-2",
					children: media.genres.map((g) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/discover",
						search: discoverSearch({ genre: g }),
						className: "text-sm text-muted hover:text-fg",
						children: g
					}, g))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 flex flex-wrap justify-center gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/watch/$id",
							params: { id: String(media.id) },
							search: { ep: resume },
							className: solidBtn,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, {
								className: "size-4",
								fill: "currentColor"
							}), progress ? `Continue ${resume}` : media.kind === "MANGA" ? "Open" : "Watch"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: ghostBtn,
							onClick: () => toggle(media.id),
							children: saved ? "Following" : "Follow"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: ghostBtn,
							onClick: () => {
								const next = randomMedia(media.kind);
								if (next) navigate({
									to: "/title/$id",
									params: { id: String(next.id) }
								});
							},
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shuffle, { className: "size-4" }), "Random"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: ghostBtn,
							onClick: () => {
								navigator.clipboard?.writeText(window.location.href).then(() => {
									setCopied(true);
									window.setTimeout(() => setCopied(false), 1600);
								});
							},
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Share2, { className: "size-4" }), copied ? "Copied" : "Share"]
						})
					]
				})
			]
		})]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto max-w-4xl px-4 pb-12",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex items-end justify-between gap-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-lg font-semibold",
					children: "Details"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted",
					children: ["More about ", media.title]
				})] })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4 flex gap-1 overflow-x-auto rounded-2xl border border-line bg-surface p-1",
				children: TABS.map((name) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setTab(name),
					className: cn("h-11 shrink-0 rounded-xl px-3 text-sm", tab === name ? "bg-raised text-fg" : "text-muted"),
					children: name
				}, name))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 rounded-2xl border border-line bg-surface p-4 sm:p-6",
				children: [
					tab === "Overview" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex flex-wrap gap-2",
							children: media.genres.map((g) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/discover",
								search: discoverSearch({ genre: g }),
								className: "rounded-full bg-raised px-3 py-1 text-micro text-fg",
								children: g
							}, g))
						}),
						media.relations.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-6",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-micro tracking-widest text-faint uppercase",
								children: "Related"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "mt-2 divide-y divide-line",
								children: media.relations.map((rel) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "flex items-center justify-between gap-3 py-2",
									children: [inCatalog(rel.id) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
										to: "/title/$id",
										params: { id: String(rel.id) },
										className: "text-sm hover:text-accent",
										children: rel.title
									}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-sm text-muted",
										children: rel.title
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "shrink-0 rounded-md bg-raised px-2 py-1 text-micro tracking-wide text-accent uppercase",
										children: rel.relation.replaceAll("_", " ")
									})]
								}, `${rel.relation}-${rel.id}`))
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
							className: "mt-6 grid grid-cols-2 gap-4 sm:grid-cols-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fact, {
									k: "Format",
									v: formatLabel(media.format)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fact, {
									k: media.kind === "MANGA" ? "Chapters" : "Episodes",
									v: String(media.kind === "MANGA" ? media.chapters ?? total : media.episodes ?? total)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fact, {
									k: "Duration",
									v: media.duration ? `${media.duration} min` : "—"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fact, {
									k: "Score",
									v: media.score ? `${media.score}%` : "—"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fact, {
									k: "Status",
									v: statusLabel(media.status)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fact, {
									k: "Studio",
									v: media.studio ?? "—"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fact, {
									k: "Source",
									v: media.kind === "MANGA" ? "Manga" : "Catalog"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fact, {
									k: "Season",
									v: seasonText(media)
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-6 space-y-3 text-sm leading-relaxed text-muted",
							children: paras.length ? paras.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: p }, p.slice(0, 24))) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "No synopsis on file." })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 text-micro text-faint",
							children: "(Metadata: AniList)"
						})
					] }),
					tab === "Episodes" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EpisodeList, {
						id: media.id,
						total,
						kindLabel: media.kind === "MANGA" ? "Chapter" : "Episode",
						titles: media
					}),
					tab === "Trailer" && (media.trailer ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "aspect-video overflow-hidden rounded-xl",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("iframe", {
							className: "h-full w-full",
							src: `https://www.youtube-nocookie.com/embed/${media.trailer}?rel=0`,
							title: `${media.title} trailer`,
							allow: "autoplay; encrypted-media; picture-in-picture",
							allowFullScreen: true
						})
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "No official trailer is on file for this title."
					})),
					tab === "More like this" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4",
						children: more.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Poster, { media: item }, item.id))
					})
				]
			})
		]
	})] });
}
function Fact({ k, v }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
		className: "text-micro tracking-widest text-faint uppercase",
		children: k
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
		className: "mt-1 text-sm font-medium",
		children: v
	})] });
}
function EpisodeList({ id, total, kindLabel, titles }) {
	const size = 24;
	const [range, setRange] = (0, import_react.useState)(0);
	const pages = Math.max(1, Math.ceil(total / size));
	const start = range * size;
	const count = Math.min(size, total - start);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [pages > 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "mb-3 flex items-center gap-2 text-sm text-muted",
		children: ["Range", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
			value: range,
			onChange: (e) => setRange(Number(e.target.value)),
			className: "h-11 rounded-xl border border-line bg-bg px-3 text-fg",
			children: Array.from({ length: pages }, (_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
				value: i,
				children: [
					i * size + 1,
					"–",
					Math.min(total, (i + 1) * size)
				]
			}, i))
		})]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "divide-y divide-line",
		children: Array.from({ length: count }, (_, i) => {
			const n = start + i + 1;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/watch/$id",
				params: { id: String(id) },
				search: { ep: n },
				className: "flex items-center justify-between gap-3 py-3 text-sm hover:text-accent",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
					kindLabel,
					" ",
					n,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mt-0.5 block text-micro text-muted",
						children: episodeTitle(titles, n)
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-4 shrink-0" })]
			}) }, n);
		})
	})] });
}
//#endregion
export { TitlePage as component };
