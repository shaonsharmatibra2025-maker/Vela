import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { Shell, Score, useKind } from "@/components/chrome";
import { filterMedia, getMedia } from "@/data/catalog";
import { formatLabel, statusLabel } from "@/lib/format";
import { useLibrary, type ThemeName } from "@/lib/library";
import { cn } from "@/lib/cn";

export const Route = createFileRoute("/studio")({
  head: () => ({ meta: [{ title: "Studio · Vela" }] }),
  component: Studio,
});

const THEMES: { id: ThemeName; name: string; line: string }[] = [
  { id: "night", name: "Night", line: "Near-black canvas, cream button, gold score." },
  { id: "ember", name: "Ember", line: "Warmer blacks and a stronger gold." },
  { id: "dawn", name: "Dawn", line: "Paper background, ink text, dark button." },
];

function Studio() {
  const kind = useKind();
  const theme = useLibrary((s) => s.theme);
  const setTheme = useLibrary((s) => s.setTheme);
  const reduceMotion = useLibrary((s) => s.reduceMotion);
  const setReduceMotion = useLibrary((s) => s.setReduceMotion);
  const featuredId = useLibrary((s) => s.featuredId);
  const setFeatured = useLibrary((s) => s.setFeatured);
  const notes = useLibrary((s) => s.notes);
  const hiddenNotes = useLibrary((s) => s.hiddenNotes);
  const hideNote = useLibrary((s) => s.hideNote);
  const [q, setQ] = useState("");
  const featured = featuredId ? getMedia(featuredId) : undefined;

  const rows = useMemo(() => filterMedia({ kind, q, sort: "popular" }).slice(0, 24), [kind, q]);
  const visibleNotes = notes.filter((n) => !hiddenNotes.includes(n.id)).slice(0, 12);

  return (
    <Shell>
      <main className="mx-auto max-w-5xl px-4 py-8">
        <p className="text-micro tracking-widest text-faint uppercase">Studio</p>
        <h1 className="mt-1 font-display text-3xl font-bold">Arrange the shelf</h1>
        <p className="mt-2 max-w-xl text-sm text-muted">
          Pin the home hero, switch the room, and hide a note. Playback is the official trailer on YouTube. Vela does not host episode files.
        </p>

        <section className="mt-8">
          <h2 className="text-sm font-semibold">Appearance</h2>
          <div className="mt-3 grid gap-3 sm:grid-cols-3">
            {THEMES.map((item) => (
              <button
                key={item.id}
                type="button"
                onClick={() => setTheme(item.id)}
                className={cn(
                  "rounded-2xl border p-4 text-left",
                  theme === item.id ? "border-accent bg-surface" : "border-line bg-surface",
                )}
              >
                <p className="font-semibold">{item.name}</p>
                <p className="mt-1 text-sm text-muted">{item.line}</p>
              </button>
            ))}
          </div>
          <label className="mt-3 flex items-center gap-3 text-sm">
            <input
              type="checkbox"
              checked={reduceMotion}
              onChange={(e) => setReduceMotion(e.target.checked)}
              className="size-4 accent-gold"
            />
            Reduced motion
          </label>
        </section>

        <section className="mt-10">
          <h2 className="text-sm font-semibold">Featured</h2>
          <p className="mt-1 text-sm text-muted">This title holds the home hero until you clear it. Otherwise the shelf rotates.</p>
          <div className="mt-3 flex items-center gap-3 rounded-2xl border border-line bg-surface p-3">
            {featured ? (
              <>
                <img src={featured.cover} alt="" className="h-20 w-14 rounded-lg object-cover" />
                <div className="min-w-0 flex-1">
                  <p className="truncate font-semibold">{featured.title}</p>
                  <p className="text-micro text-muted">{featured.year ?? "—"} · {formatLabel(featured.format)}</p>
                </div>
                <button type="button" className="h-11 rounded-full border border-line px-4 text-sm" onClick={() => setFeatured(null)}>
                  Clear
                </button>
              </>
            ) : (
              <p className="text-sm text-muted">No pin. Home is using the rotating row.</p>
            )}
          </div>
          <label className="mt-3 block text-sm">
            <span className="text-muted">Find a title to pin</span>
            <input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder={kind === "MANGA" ? "Search manga" : "Search anime"}
              className="mt-1 h-11 w-full rounded-full border border-line bg-surface px-4 text-sm"
            />
          </label>
          <ul className="mt-3 divide-y divide-line overflow-hidden rounded-2xl border border-line">
            {rows.map((item) => (
              <li key={item.id} className="flex items-center gap-3 bg-surface px-3 py-2">
                <img src={item.cover} alt="" className="h-12 w-8 rounded object-cover" />
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-medium">{item.title}</p>
                  <p className="text-micro text-muted">
                    {statusLabel(item.status)} · {item.year ?? "—"}
                  </p>
                </div>
                <Score value={item.score} />
                <button
                  type="button"
                  className="h-11 shrink-0 rounded-full bg-accent px-3 text-sm font-semibold text-accent-ink"
                  onClick={() => setFeatured(item.id)}
                >
                  Pin
                </button>
                <Link to="/title/$id" params={{ id: String(item.id) }} className="hidden h-11 items-center text-sm text-muted sm:inline-flex">
                  Open
                </Link>
              </li>
            ))}
          </ul>
        </section>

        <section className="mt-10">
          <h2 className="text-sm font-semibold">Notes on this device</h2>
          {visibleNotes.length === 0 ? (
            <p className="mt-2 text-sm text-muted">No notes yet. They show up after someone writes under an episode.</p>
          ) : (
            <ul className="mt-3 space-y-2">
              {visibleNotes.map((note) => {
                const show = getMedia(note.mediaId);
                return (
                  <li key={note.id} className="flex items-start justify-between gap-3 rounded-2xl border border-line bg-surface p-3">
                    <div className="min-w-0">
                      <p className="text-micro text-muted">{show?.title ?? "Title"} · ep {note.episode}</p>
                      <p className="mt-1 text-sm">{note.text}</p>
                    </div>
                    <button type="button" className="h-11 shrink-0 text-sm text-danger" onClick={() => hideNote(note.id)}>
                      Hide
                    </button>
                  </li>
                );
              })}
            </ul>
          )}
        </section>
      </main>
    </Shell>
  );
}