import { useEffect, useState } from "react";
import { useLibrary } from "@/lib/library";
import { ago } from "@/lib/format";

export function LibraryBoot() {
  const theme = useLibrary((s) => s.theme);
  const reduceMotion = useLibrary((s) => s.reduceMotion);
  useEffect(() => {
    void useLibrary.persist.rehydrate();
  }, []);
  useEffect(() => {
    document.documentElement.dataset.theme = theme;
    document.documentElement.dataset.motion = reduceMotion ? "reduce" : "full";
  }, [theme, reduceMotion]);
  return null;
}

export function Ago({ at }: { at: number }) {
  const [label, setLabel] = useState("earlier");
  useEffect(() => setLabel(ago(at)), [at]);
  return <span>{label}</span>;
}

export function When({ at }: { at: number }) {
  const [label, setLabel] = useState("Scheduled");
  useEffect(() => {
    setLabel(
      new Intl.DateTimeFormat(undefined, {
        weekday: "short",
        month: "short",
        day: "numeric",
        hour: "numeric",
        minute: "2-digit",
      }).format(at * 1000),
    );
  }, [at]);
  return <span className="tabular-nums">{label}</span>;
}