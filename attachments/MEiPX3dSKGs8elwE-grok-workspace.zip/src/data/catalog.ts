import raw from "./catalog.json";

export type Kind = "ANIME" | "MANGA";

export type Episode = { n: number; title: string; thumb: string | null };

export type Relation = {
  id: number;
  relation: string;
  title: string;
  kind: string;
};

export type Media = {
  id: number;
  kind: Kind;
  title: string;
  romaji: string;
  native: string;
  synopsis: string;
  cover: string;
  banner: string | null;
  color: string | null;
  score: number;
  year: number | null;
  season: string | null;
  format: string;
  episodes: number | null;
  chapters: number | null;
  duration: number | null;
  status: string;
  genres: string[];
  studio: string | null;
  trailer: string | null;
  popularity: number;
  nextAiring: { at: number; episode: number } | null;
  relations: Relation[];
  recs: number[];
  episodeList: Episode[];
};

type CatalogFile = { media: Media[]; rails: Record<string, number[]> };

const data = raw as CatalogFile;
const media = data.media.filter((m) => m.kind === "ANIME" || m.kind === "MANGA");
const byId = new Map(media.map((m) => [m.id, m]));

export function allMedia() {
  return media;
}

export function getMedia(id: number) {
  return byId.get(id);
}

export function rail(name: string) {
  const ids = data.rails[name] ?? [];
  const out: Media[] = [];
  for (const id of ids) {
    const item = byId.get(id);
    if (item) out.push(item);
  }
  return out;
}

export function counts() {
  let anime = 0;
  let manga = 0;
  let trailers = 0;
  for (const item of media) {
    if (item.kind === "ANIME") anime += 1;
    else manga += 1;
    if (item.trailer) trailers += 1;
  }
  return { anime, manga, trailers, all: media.length };
}

export type FilterOpts = {
  kind: Kind;
  q?: string;
  genre?: string;
  format?: string;
  status?: string;
  sort?: string;
};

export function filterMedia(opts: FilterOpts) {
  const q = (opts.q ?? "").trim().toLowerCase();
  let items = media.filter((m) => m.kind === opts.kind);
  if (q) {
    items = items.filter(
      (m) =>
        m.title.toLowerCase().includes(q) ||
        m.romaji.toLowerCase().includes(q) ||
        m.native.toLowerCase().includes(q) ||
        m.genres.some((g) => g.toLowerCase().includes(q)) ||
        (m.studio ?? "").toLowerCase().includes(q),
    );
  }
  if (opts.genre) items = items.filter((m) => m.genres.includes(opts.genre as string));
  if (opts.format) items = items.filter((m) => m.format === opts.format);
  if (opts.status) items = items.filter((m) => m.status === opts.status);
  const copy = [...items];
  const sort = opts.sort ?? "popular";
  if (sort === "score") copy.sort((a, b) => b.score - a.score || b.popularity - a.popularity);
  else if (sort === "year") copy.sort((a, b) => (b.year ?? 0) - (a.year ?? 0) || b.popularity - a.popularity);
  else if (sort === "title") copy.sort((a, b) => a.title.localeCompare(b.title));
  else copy.sort((a, b) => b.popularity - a.popularity);
  return copy;
}

export function genreCounts(kind: Kind) {
  const map = new Map<string, number>();
  for (const item of media) {
    if (item.kind !== kind) continue;
    for (const genre of item.genres) map.set(genre, (map.get(genre) ?? 0) + 1);
  }
  return [...map.entries()].sort((a, b) => b[1] - a[1]);
}

export function facetValues(kind: Kind, key: "format" | "status") {
  return [...new Set(media.filter((m) => m.kind === kind).map((m) => m[key]))].sort();
}

export function hiddenGems(kind: Kind) {
  return media
    .filter((m) => m.kind === kind && m.score >= 80)
    .sort((a, b) => a.popularity - b.popularity)
    .slice(0, 14);
}

export function newest(kind: Kind) {
  return media
    .filter((m) => m.kind === kind)
    .sort((a, b) => (b.year ?? 0) - (a.year ?? 0) || b.popularity - a.popularity)
    .slice(0, 16);
}

export function topRated(kind: Kind, n = 10) {
  return media
    .filter((m) => m.kind === kind && m.score > 0)
    .sort((a, b) => b.score - a.score || b.popularity - a.popularity)
    .slice(0, n);
}

export function schedule(kind: Kind) {
  return media
    .filter((m) => m.kind === kind && m.nextAiring)
    .sort((a, b) => (a.nextAiring?.at ?? 0) - (b.nextAiring?.at ?? 0));
}

export function recsFor(item: Media) {
  const out: Media[] = [];
  for (const id of item.recs) {
    const hit = byId.get(id);
    if (hit && hit.id !== item.id) out.push(hit);
  }
  if (out.length < 8) {
    for (const other of media) {
      if (out.length >= 12) break;
      if (other.id === item.id || other.kind !== item.kind) continue;
      if (out.some((o) => o.id === other.id)) continue;
      if (other.genres.some((g) => item.genres.includes(g))) out.push(other);
    }
  }
  return out.slice(0, 12);
}

export function randomMedia(kind: Kind) {
  const pool = media.filter((m) => m.kind === kind);
  return pool[Math.floor(Math.random() * pool.length)];
}

export function inCatalog(id: number) {
  return byId.has(id);
}
